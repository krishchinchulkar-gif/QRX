import { QrCode, Gamepad2, Music2, Brain, Images, ShieldCheck } from "lucide-react";

const features = [
  [QrCode, "One QR. Any experience.", "A QR can open a game today and a completely different experience later."],
  [Gamepad2, "Browser games", "Send people straight into lightweight games without an app download."],
  [Music2, "Music", "Connect songs or playlists and give visitors a clean mobile listening page."],
  [Brain, "Quizzes & cards", "Build quizzes, choices, riddles and interactive card experiences."],
  [Images, "Visual choices", "Show images with tap-to-choose actions for your custom experiences."],
  [ShieldCheck, "Private control", "Only your authenticated admin account can create or change experiences."],
] as const;

export default function Home() {
  return (
    <main>
      <section className="hero container">
        <div className="eyebrow">QRX • Interactive QR Platform</div>
        <h1>Scan a code.<br />Unlock an experience.</h1>
        <p>Create QR codes that can open games, quizzes, music, image choices and custom interactive pages — all from one place.</p>
        <div className="actions">
          <a className="btn" href="/admin">Open Admin</a>
          <a className="btn secondary" href="#features">See what it can do</a>
        </div>
      </section>

      <section id="features" className="section container">
        <div className="sectionTitle">
          <h2>Built for your QR ideas</h2>
          <p className="muted">Start simple, then keep adding new experience types.</p>
        </div>
        <div className="grid">
          {features.map(([Icon, title, desc]) => (
            <div className="card" key={title}>
              <div className="iconBox"><Icon size={21} /></div>
              <h3>{title}</h3>
              <p className="muted">{desc}</p>
            </div>
          ))}
        </div>
      </section>

      <footer className="footer container">QRX — your QR experience hub.</footer>
    </main>
  );
}
