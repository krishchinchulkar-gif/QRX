import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "QRX — Interactive QR Experiences",
  description: "Create QR codes that open games, quizzes, music, cards and more.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <>
      <header className="topbar">
        <div className="container nav">
          <a href="/" className="brand"><span className="brandMark">Q</span><span>QRX</span></a>
          <nav className="navlinks">
            <a href="/">Home</a>
            <a href="/admin">Admin</a>
          </nav>
        </div>
      </header>
      {children}
    </>
  );
}
