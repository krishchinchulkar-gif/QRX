 "use client";

import { useEffect, useState } from "react";
import QRCode from "qrcode";
import { createClient } from "@/lib/supabase";
import { Plus, Download, LogOut, ExternalLink, Trash2, RefreshCw } from "lucide-react";

type Experience = {
  id: string;
  slug: string;
  title: string;
  type: string;
  description: string | null;
  content: any;
  active: boolean;
  visits: number;
  created_at: string;
};

const types = ["music", "quiz", "game", "cards", "choice", "custom"];

export default function AdminClient() {
  const supabase = createClient();
  const [session, setSession] = useState<any>(null);
  const [items, setItems] = useState<Experience[]>([]);
  const [loading, setLoading] = useState(true);
  const [authMode, setAuthMode] = useState<"login"|"signup">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({
    title: "", slug: "", type: "choice", description: "",
    image_url: "", button_text: "Open", target_url: "",
    choices: '[{"label":"Choice A","image_url":""},{"label":"Choice B","image_url":""}]'
  });

  useEffect(() => {
    supabase.auth.getSession().then(({data}) => {
      setSession(data.session);
      if (data.session) load();
      else setLoading(false);
    });
    const {data: listener} = supabase.auth.onAuthStateChange((_event, next) => {
      setSession(next);
      if (next) load();
    });
    return () => listener.subscription.unsubscribe();
  }, []);

  async function load() {
    setLoading(true);
    const {data, error} = await supabase.from("experiences").select("*").order("created_at", {ascending:false});
    if (error) setError(error.message);
    setItems(data || []);
    setLoading(false);
  }

  async function auth() {
    setError("");
    const fn = authMode === "login" ? supabase.auth.signInWithPassword({email,password}) : supabase.auth.signUp({email,password});
    const {error} = await fn;
    if (error) setError(error.message);
  }

  async function createExperience() {
    setError("");
    let content: any = {
      image_url: form.image_url,
      button_text: form.button_text,
      target_url: form.target_url
    };
    if (form.type === "choice" || form.type === "cards") {
      try { content.choices = JSON.parse(form.choices); }
      catch { setError("Choices must be valid JSON."); return; }
    }
    const slug = form.slug.trim() || Math.random().toString(36).slice(2,9);
    const {error} = await supabase.from("experiences").insert({
      slug, title: form.title, type: form.type,
      description: form.description, content, active: true, visits: 0
    });
    if (error) setError(error.message);
    else {
      setShowForm(false);
      setForm({...form, title:"", slug:"", description:"", image_url:"", target_url:""});
      load();
    }
  }

  async function remove(id:string) {
    if (!confirm("Delete this experience?")) return;
    const {error} = await supabase.from("experiences").delete().eq("id", id);
    if (error) setError(error.message); else load();
  }

  async function downloadQR(item: Experience) {
    const url = `${window.location.origin}/e/${item.slug}`;
    const data = await QRCode.toDataURL(url, {width: 1200, margin: 2});
    const a = document.createElement("a");
    a.href = data; a.download = `QRX-${item.slug}.png`; a.click();
  }

  if (!session) return (
    <main className="center">
      <div className="panel auth">
        <div className="eyebrow">Private control room</div>
        <h1 style={{fontSize:38}}>Your Admin</h1>
        <p className="muted">Only authenticated accounts can manage QR experiences.</p>
        <div className="field"><label>Email</label><input value={email} onChange={e=>setEmail(e.target.value)} /></div>
        <div className="field" style={{marginTop:12}}><label>Password</label><input type="password" value={password} onChange={e=>setPassword(e.target.value)} /></div>
        {error && <div className="error" style={{marginTop:12}}>{error}</div>}
        <button className="btn" style={{width:"100%",marginTop:15}} onClick={auth}>{authMode === "login" ? "Sign in" : "Create account"}</button>
        <button className="ghost" style={{width:"100%",border:0,background:"transparent",marginTop:8}} onClick={()=>setAuthMode(authMode==="login"?"signup":"login")}>
          {authMode === "login" ? "Create the first account" : "Back to sign in"}
        </button>
      </div>
    </main>
  );

  return (
    <main className="dashboard container">
      <div className="dashboardHead">
        <div><div className="eyebrow">Control room</div><h1>Experiences</h1></div>
        <div className="actions">
          <button className="btn secondary" onClick={load}><RefreshCw size={16}/> Refresh</button>
          <button className="btn secondary" onClick={()=>supabase.auth.signOut()}><LogOut size={16}/> Sign out</button>
          <button className="btn" onClick={()=>setShowForm(true)}><Plus size={17}/> Create</button>
        </div>
      </div>

      <div className="stats">
        <div className="stat"><span className="muted">Experiences</span><strong>{items.length}</strong></div>
        <div className="stat"><span className="muted">Total visits</span><strong>{items.reduce((n,x)=>n+(x.visits||0),0)}</strong></div>
        <div className="stat"><span className="muted">Active</span><strong>{items.filter(x=>x.active).length}</strong></div>
      </div>

      {error && <div className="error" style={{marginBottom:15}}>{error}</div>}

      {showForm && <div className="panel" style={{marginBottom:20}}>
        <h2>Create experience</h2>
        <div className="formGrid">
          <div className="field"><label>Title</label><input value={form.title} onChange={e=>setForm({...form,title:e.target.value})} placeholder="My first QR" /></div>
          <div className="field"><label>Type</label><select value={form.type} onChange={e=>setForm({...form,type:e.target.value})}>{types.map(t=><option key={t}>{t}</option>)}</select></div>
          <div className="field"><label>Custom slug (optional)</label><input value={form.slug} onChange={e=>setForm({...form,slug:e.target.value.replace(/[^a-zA-Z0-9-_]/g,"")})} placeholder="my-qr" /></div>
          <div className="field"><label>Cover image URL</label><input value={form.image_url} onChange={e=>setForm({...form,image_url:e.target.value})} placeholder="https://..." /></div>
          <div className="field full"><label>Description</label><textarea value={form.description} onChange={e=>setForm({...form,description:e.target.value})} placeholder="What should visitors see?" /></div>
          {(form.type === "choice" || form.type === "cards") && <div className="field full"><label>Choices JSON</label><textarea value={form.choices} onChange={e=>setForm({...form,choices:e.target.value})} /></div>}
          <div className="field"><label>Button text</label><input value={form.button_text} onChange={e=>setForm({...form,button_text:e.target.value})} /></div>
          <div className="field"><label>Target URL (music/game/custom)</label><input value={form.target_url} onChange={e=>setForm({...form,target_url:e.target.value})} placeholder="https://..." /></div>
        </div>
        <div className="actions" style={{justifyContent:"flex-start",marginTop:17}}>
          <button className="btn" onClick={createExperience}>Create QR experience</button>
          <button className="btn secondary" onClick={()=>setShowForm(false)}>Cancel</button>
        </div>
      </div>}

      <div className="panel" style={{overflowX:"auto"}}>
        {loading ? <p className="muted">Loading…</p> : items.length === 0 ? <p className="muted">No experiences yet. Create your first one.</p> :
        <table className="table"><thead><tr><th>Experience</th><th>Type</th><th>Visits</th><th>Actions</th></tr></thead><tbody>
          {items.map(item=><tr key={item.id}>
            <td><strong>{item.title}</strong><br/><span className="muted small">/e/{item.slug}</span></td>
            <td><span className="badge">{item.type}</span></td>
            <td>{item.visits || 0}</td>
            <td><div className="actions" style={{justifyContent:"flex-start"}}>
              <button className="btn secondary" onClick={()=>downloadQR(item)}><Download size={15}/> QR</button>
              <a className="btn secondary" href={`/e/${item.slug}`} target="_blank"><ExternalLink size={15}/></a>
              <button className="btn danger" onClick={()=>remove(item.id)}><Trash2 size={15}/></button>
            </div></td>
          </tr>)}
        </tbody></table>}
      </div>
    </main>
  );
}
