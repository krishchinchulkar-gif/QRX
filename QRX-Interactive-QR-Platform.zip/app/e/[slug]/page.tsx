import { createClient } from "@/lib/supabase";
import ExperienceClient from "./ExperienceClient";

export default async function ExperiencePage({params}:{params:Promise<{slug:string}>}) {
  const {slug} = await params;
  const supabase = createClient();
  const {data} = await supabase.from("experiences").select("*").eq("slug",slug).eq("active",true).single();

  if (!data) return (
    <main className="center"><div className="panel" style={{textAlign:"center",maxWidth:500}}>
      <div className="eyebrow">QRX</div><h1 style={{fontSize:42}}>Not found</h1><p className="muted">This QR experience doesn't exist or has been disabled.</p><a className="btn" href="/">Go home</a>
    </div></main>
  );

  // Incrementing visits client-side avoids exposing a public UPDATE policy.
  return <ExperienceClient experience={data} />;
}
