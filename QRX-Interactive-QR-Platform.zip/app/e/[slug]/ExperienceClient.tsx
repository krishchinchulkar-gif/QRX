 "use client";

import { useEffect } from "react";
import { ExternalLink, Play, Sparkles } from "lucide-react";
import { createClient } from "@/lib/supabase";

export default function ExperienceClient({experience}:any) {
  const supabase = createClient();
  const c = experience.content || {};

  useEffect(() => {
    // A production version should move visit counting to a protected server endpoint.
    supabase.rpc("record_visit", {experience_slug: experience.slug}).then(()=>{});
  }, []);

  const open = (url:string) => {
    if (url) window.open(url, "_blank", "noopener,noreferrer");
  };

  return (
    <main className="experience">
      <div className="experienceShell">
        <div className="eyebrow"><Sparkles size={14} style={{verticalAlign:"-2px"}}/> QR EXPERIENCE</div>
        <h1>{experience.title}</h1>
        {experience.description && <p className="muted" style={{fontSize:17,lineHeight:1.7}}>{experience.description}</p>}
        {c.image_url && <img className="cover" src={c.image_url} alt="" />}

        {experience.type === "choice" || experience.type === "cards" ? (
          <div className="choiceGrid">
            {(c.choices || []).map((choice:any, i:number) =>
              <button className="choice" key={i} onClick={()=>choice.url ? open(choice.url) : alert(choice.label)}>
                {choice.image_url && <img src={choice.image_url} alt="" />}
                <span>{choice.label}</span>
              </button>
            )}
          </div>
        ) : (
          <button className="bigButton" onClick={()=>open(c.target_url)}>
            {experience.type === "game" ? <Play size={17}/> : <ExternalLink size={17}/>}
            {c.button_text || "Open experience"}
          </button>
        )}
      </div>
    </main>
  );
}
