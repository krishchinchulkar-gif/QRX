-- QRX database
-- Run this in Supabase SQL Editor.

create extension if not exists pgcrypto;

create table if not exists public.experiences (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  slug text not null unique,
  title text not null,
  type text not null check (type in ('music','quiz','game','cards','choice','custom')),
  description text,
  content jsonb not null default '{}'::jsonb,
  active boolean not null default true,
  visits bigint not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.experiences enable row level security;

-- Owners can manage their own experiences.
create policy "owners select own experiences"
on public.experiences for select
to authenticated
using (owner_id = auth.uid());

create policy "owners insert own experiences"
on public.experiences for insert
to authenticated
with check (owner_id = auth.uid());

create policy "owners update own experiences"
on public.experiences for update
to authenticated
using (owner_id = auth.uid())
with check (owner_id = auth.uid());

create policy "owners delete own experiences"
on public.experiences for delete
to authenticated
using (owner_id = auth.uid());

-- Public QR pages need to read active experiences.
create policy "public read active experiences"
on public.experiences for select
to anon
using (active = true);

-- Safe visit counter: visitors cannot arbitrarily edit rows.
create or replace function public.record_visit(experience_slug text)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  update public.experiences
  set visits = visits + 1, updated_at = now()
  where slug = experience_slug and active = true;
end;
$$;

revoke all on function public.record_visit(text) from public;
grant execute on function public.record_visit(text) to anon, authenticated;

-- Optional: automatically update updated_at on changes.
create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists experiences_updated_at on public.experiences;
create trigger experiences_updated_at
before update on public.experiences
for each row execute function public.set_updated_at();
